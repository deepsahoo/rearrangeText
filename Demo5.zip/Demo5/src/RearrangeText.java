
public class RearrangeText {

	public static void main(String[] args) {
		String testString = "the black cat jumped on the roof";
		System.out.println(findCombinationAndRearrangeText(testString));

	}
	/*
	 * 1. replace All space with "" an ffind L -> L = 8 
	 * 2. preSqt = sqrt(4) = 2 
	 * 3.
	 * postSqrt = sqrt(9) = 3 
	 * 4. 2<= R<=C<=3 and R*C >= L
	 * 5. R = 2, C = 3 2*3<8 :
	 *     fail R = 3, C=3 3*3>=8 9>=8 pass 6.
	 */
	static String findCombinationAndRearrangeText(String str){
		String withoutSpace = str.replaceAll("\\s", "");
		int L = withoutSpace.length();
		boolean isLowSqrtFound = false;
		boolean isHighSqrtFound = false;
		int lowSqurt=0;
		int highSqurt=0;
		int tempL = L;
		int R;
		int C;
		while(!isLowSqrtFound) {
			tempL--;
			double sqrt = Math.sqrt(tempL);
			if(Math.floor(sqrt)-sqrt==0) {
				isLowSqrtFound = true;
				lowSqurt = (int) sqrt;
				break;
			}
		}
		tempL = L;
		while(!isHighSqrtFound) {
			tempL++;
			double sqrt = Math.sqrt(tempL);
			if(Math.floor(sqrt)-sqrt==0) {
				isHighSqrtFound = true;
				highSqurt = (int) sqrt;
				break;
			}
		}
		
		//find R and C
		R= lowSqurt;
		C = highSqurt;
		int tempR = R;
		int tempC = C;
		if(R*C<L) {
			for(int i=R;i<=tempC;i++) {
				for(int j=C;j>=tempR&&j<=tempC;j++) {
					if(i*j>=L) {
						R=i;
						C=j;
						break;
					}
				}
			}
		}
		
	    //fill the matrix
		char matrix[][] = new char[R][C];
		int pos = 0;
		for(int i=0;i<R;i++) {
			for(int j=0;j<C;j++) {
				if(pos<withoutSpace.length()) {
					matrix[i][j] = withoutSpace.charAt(pos);
					pos++;
				}else {
					break;
				}
				
			}
		}
		StringBuffer result = new StringBuffer();
		//decrypt the matrix
		for(int i=0;i<C;i++) {
			for(int j=0;j<R;j++) {
				if(matrix[j][i] != '\0'){
					result.append(matrix[j][i]);
				}
			}
			result.append(" ");
		}
		return result.toString();
	}

}
